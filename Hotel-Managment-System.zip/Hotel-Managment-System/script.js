let btndashboard = document.querySelector('#dashboard');
let btnbooking = document.querySelector('#booking');
let btnrecord = document.querySelector('#record');
let btnemployee = document.querySelector('#employee');
let btnincome = document.querySelector('#income');
let btnresturent = document.querySelector('#resturent');
let btnterminate = document.querySelector('#terminate');

btndashboard.addEventListener('click', () => btndashboard.style.backgroundColor = '#f00')
btnbooking.addEventListener('click', () => btnbooking.style.backgroundColor = '#f00')
btnrecord.addEventListener('click', () => btnrecord.style.backgroundColor = '#f00')
btnemployee.addEventListener('click', () => btnemployee.style.backgroundColor = '#f00')
btnincome.addEventListener('click', () => btnincome.style.backgroundColor = '#f00')
btnresturent.addEventListener('click', () => btnresturent.style.backgroundColor = '#f00')
btnterminate.addEventListener('click', () => btnterminate.style.backgroundColor = '#f00')