$(document).ready(function(){
    $('#inputdrug').selectpicker();
})